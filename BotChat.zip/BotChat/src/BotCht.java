
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.net.URI;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import static javax.swing.text.StyleConstants.ALIGN_RIGHT;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author umash
 */
public class BotCht extends javax.swing.JFrame {

    Connection conn;
    ResultSet rs;
    PreparedStatement pst;
    
    public BotCht() {
        initComponents();
        this.setTitle("TechSuggest");
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        
        
        conn=javaconnect.ConnecrDb();
        
        
        
        
        txtEnter.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0) {
                String uText = txtEnter.getText();
                String You= "You :";
                ArrayList<String> list=new ArrayList<>(Arrays.asList("Hey","Hi","Hello","Hola")); // Greetings
              
                ArrayList<String> list1=new ArrayList<>(Arrays.asList("Help","Support","Assistance")); // Help
              
                ArrayList<String> list2=new ArrayList<>(Arrays.asList("What are you?"));
                
                ArrayList<String> list3=new ArrayList<>(Arrays.asList("date"));
                
                ArrayList<String> Phones=new ArrayList<>(Arrays.asList("OnePlus6T","Huawei Mate20Pro","Iphone XS","Asus Zenphone 5Z"));
                
                ArrayList<String> Prices=new ArrayList<>(Arrays.asList("40000"));
                
                
                
                
                for(String str : Phones){
                if(uText.toLowerCase().contains(str.toLowerCase()))
                {
                    String sql="select * from Phones where Name='"+str+"'";
                    try{
            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
        if(rs.next()){
            ISay(uText);
            botSay("Name:"+rs.getString(1)+" "+"Performance:"+rs.getString(2)+" "+"Display:"+rs.getString(3)+" "+"CAM:"+rs.getString(4)+" "+"RAM:"+rs.getString(5)+" "+"Storage:"+rs.getString(6)+" "+"Price:"+rs.getString(7));
            String site=rs.getString(9);
            URI uri= new URI(site);
            URL url=uri.toURL();
            botUay(url);
            byte[] im=rs.getBytes(8);
            ImageIcon image= new ImageIcon(im);
            Image img=image.getImage();
            txtChat.insertIcon ( new ImageIcon (img) );
            Space();
            rs.close();
            pst.close();
        }
        else{
            
                    }
        }catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
                }
                }
                    }
                
                for(String str: Prices)
                if(uText.toLowerCase().contains(str.toLowerCase()))
                {
                    String sql="select * from Phones where Price='"+str+"'";
                    try{
            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
        if(rs.next()){
            ISay(uText);
            botSay("Name:"+rs.getString(1)+" "+"Performance:"+rs.getString(2)+" "+"Display:"+rs.getString(3)+" "+"CAM:"+rs.getString(4)+" "+"RAM:"+rs.getString(5)+" "+"Storage:"+rs.getString(6)+" "+"Price:"+rs.getString(7));
            String site=rs.getString(9);
            URI uri= new URI(site);
            URL url=uri.toURL();
            botUay(url);
            byte[] im=rs.getBytes(8);
            ImageIcon image= new ImageIcon(im);
            Image img=image.getImage();
            txtChat.insertIcon ( new ImageIcon (img) );
            Space();
            rs.close();
            pst.close();
        }
        else{
            
                    }
        }catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
                }
                }
                
                if(uText.toLowerCase().contains(("Show").toLowerCase()))
                {
                    Scanner scan=new Scanner(uText);
                    while(scan.hasNext())
                    {
                        if(scan.hasNextInt())
                        {
                            NotSay(scan.nextInt());
                        }
                    }
                }
                    
                
                
                
                
                
                
                

                for(String str : list) { 
                if(uText.toLowerCase().contains(str.toLowerCase())){
                    ISay(uText);
                    botSay("Hello there! Welcome to TechSuggest");
                }}
                for(String str : list1) { 
                    if(uText.toLowerCase().contains(str.toLowerCase())){
                        ISay(uText);
                        botSay("How May I help you?");
                    }}
                for(String str : list2) { 
                if(str.equalsIgnoreCase(uText)){
                    ISay(uText);
                    botSay("I am a TechSuggest Bot that will give you suggestions,comparisons and information on latest technology.");
                }}
                for(String str : list3) { 
                    if(uText.toLowerCase().contains(str.toLowerCase())){
                        ISay(uText);
                        LocalDate l=LocalDate.now();
                        String t=l.toString();
                        botSay(t);
                    }}
                
                if(uText.toLowerCase().contains(("Quit").toLowerCase())) {
                	System.exit(0);
                }
                txtEnter.setText("");
            }

            private void botSay(String s) {
                txtChat.insertIcon ( new ImageIcon ( "D:/Downloads/robot.png" ) );
                appendToPane(txtChat,"  "+s+"\n"+"\n",Color.BLACK);
            }
            
            private void NotSay(int s) {
                txtChat.insertIcon ( new ImageIcon ( "D:/Downloads/robot.png" ) );
                appendToPane(txtChat,"  "+s+"\n"+"\n",Color.BLACK);
            }
            
            private void botUay(URL s) {
                txtChat.insertIcon ( new ImageIcon ( "D:/Downloads/robot.png" ) );
                appendToPane(txtChat,"  "+s+"\n"+"\n",Color.BLACK);
            }
            
           private void Space(){
               appendToPane(txtChat,"\n",Color.BLACK);
           }
            
            private void ISay(String s) {
                txtChat.insertIcon ( new ImageIcon ( "D:/Downloads/man (1).png" ) );
                appendToPaner(txtChat,"  "+s+"\n"+"\n",Color.BLACK);
            }
            
            private void appendToPane(JTextPane tp, String msg, Color c)
    {
        StyleContext sc = StyleContext.getDefaultStyleContext();
        StyledDocument doc = txtChat.getStyledDocument();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.FontSize, 20);

        int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);
        tp.replaceSelection(msg);
    }
            
            private void appendToPaner(JTextPane tp, String msg, Color c)
    {
        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);
       
        

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.FontSize, 20);
        
        
    

        int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);
        tp.replaceSelection(msg);
    }
        });
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtChat = new javax.swing.JTextPane();
        txtEnter = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(500, 500));
        setUndecorated(true);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        txtChat.setBackground(new java.awt.Color(255, 255, 255));
        txtChat.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        txtChat.setForeground(new java.awt.Color(255, 255, 255));
        txtChat.setSelectedTextColor(new java.awt.Color(102, 102, 102));
        jScrollPane1.setViewportView(txtChat);

        txtEnter.setBackground(new java.awt.Color(102, 102, 102));
        txtEnter.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 736, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtEnter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(319, 319, 319)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BotCht.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BotCht.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BotCht.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BotCht.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
       

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BotCht().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane txtChat;
    private javax.swing.JTextField txtEnter;
    // End of variables declaration//GEN-END:variables
}
